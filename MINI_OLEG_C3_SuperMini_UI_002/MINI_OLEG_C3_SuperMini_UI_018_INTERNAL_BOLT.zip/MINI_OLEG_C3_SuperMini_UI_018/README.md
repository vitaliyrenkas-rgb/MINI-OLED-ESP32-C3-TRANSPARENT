# MINI OLEG — MINI-018 Internal Battery Bolt

## Статус

Підготовлений drop-in build для першого фізичного тесту на реальному
ESP32-C3 Super Mini + Waveshare 1.51" Transparent OLED.

**Код ще не проходив hardware test після переходу GPIO1 на батарею.**
Перший запуск потрібен для перевірки геометрії і калібрування ADC по мультиметру.

## Що змінилось від MINI-017

- окрему блискавку під батареєю прибрано;
- блискавка перенесена всередину батареї;
- гліф малюється в XOR-режимі: над порожньою частиною він білий, над
  зафарбованою частиною автоматично стає чорним;
- корпус батареї подовжено до `y=62`, тобто до нижнього краю назви місяця;
- ширина батареї лишилась 9 пікселів — рівно як у Wi-Fi-іконки;
- великий час посунуто на 2 пікселі вправо: стартова позиція `x=13`;
- батарейний ADC, фільтрація, Serial-лог і решта MINI-017 не змінювались.

## Актуальне підключення OLED

```text
OLED VCC -> 3V3
OLED GND -> GND
OLED DIN -> GPIO10
OLED CLK -> GPIO8
OLED CS  -> GPIO7
OLED DC  -> GPIO6
OLED RST -> GPIO5
BOOT     -> GPIO9
```

## Дільник батареї на GPIO1

```text
BAT+ ---- 100 kOhm ----+---- GPIO1 / ADC1_CH1
                       |
                    100 kOhm
                       |
                      GND

BAT-/HU-009 GND ------------- ESP32-C3 GND
```

Старий конденсатор/12 kOhm/bias-вузол audio-sense сюди не переноситься.

## Геометрія статусного стовпчика

```text
x = 1..9
Wi-Fi:             y = 33..42
battery terminal:  y = 43..44
battery body:      y = 45..62
lightning:         усередині battery body, XOR
clock start:       x = 13
```

Ширина Wi-Fi і батареї — 9 пікселів. Батарею не звужували, щоб не ламати
узгоджене правило однакової ширини. Додатковий баланс отримано зсувом часу
на 2 пікселі вправо.

## Перший тест і калібрування

У верхній частині скетча є чотири константи:

```cpp
static constexpr float BATTERY_VOLTAGE_SCALE = 1.000f;
static constexpr float BATTERY_VOLTAGE_OFFSET = 0.000f;
static constexpr float BATTERY_EMPTY_VOLTAGE = 3.30f;
static constexpr float BATTERY_FULL_VOLTAGE = 4.20f;
```

Перший прохід:

1. Виміряти BAT+ мультиметром.
2. Відкрити Serial Monitor `115200`.
3. Порівняти мультиметр з рядком:
   `Battery ADC: ... mV / BAT: ... V / ...%`.
4. Після реальних значень підкрутити `SCALE/OFFSET`.
5. Окремо узгодити реальні `EMPTY/FULL` для батареї HU-009.

## Бібліотеки

- U8g2
- ArduinoJson
- ESP32 Arduino core (`WiFi`, `HTTPClient`, `WebServer`, `DNSServer`,
  `Preferences`)
