# MINI OLEG — MINI-017 GPIO1 Battery UI

## Статус

Підготовлений drop-in build для першого фізичного тесту на реальному
ESP32-C3 Super Mini + Waveshare 1.51" Transparent OLED.

**Код ще не проходив hardware test після переходу GPIO1 на батарею.**
Перший запуск потрібен для перевірки геометрії і калібрування ADC по мультиметру.

## Що змінилось від MINI-016

- старий `audio-sense` на GPIO1 повністю прибраний з runtime-коду;
- GPIO1 використовується тільки як battery ADC;
- додано усереднення та легке згладжування напруги;
- у Serial раз на 5 секунд друкуються:
  - напруга на ADC після дільника;
  - розрахована напруга BAT+;
  - попередній відсоток;
- зліва від великого часу додано вертикальний статусний стовпчик:
  - Wi-Fi зверху;
  - батарея тієї самої ширини;
  - блискавка внизу;
- нижній край блискавки стоїть на `y=62`, тобто вирівняний по нижньому краю
  назви місяця;
- великий час не пересунутий: як і раніше, починається з `x=11`;
- sleep kitty лишився в прошивці як dormant Easter egg.

## Актуальне підключення OLED

```text
OLED VCC -> 3V3
OLED GND -> GND
OLED DIN -> GPIO10
OLED CLK -> GPIO8
OLED CS  -> GPIO7
OLED DC  -> GPIO6
OLED RST -> GPIO5
BOOT     -> GPIO9
```

## Дільник батареї на GPIO1

```text
BAT+ ---- 100 kOhm ----+---- GPIO1 / ADC1_CH1
                       |
                    100 kOhm
                       |
                      GND

BAT-/HU-009 GND ------------- ESP32-C3 GND
```

Старий конденсатор/12 kOhm/bias-вузол audio-sense сюди не переноситься.

## Геометрія статусного стовпчика

```text
x = 1..9
Wi-Fi:             y = 34..42
battery terminal:  y = 43..44
battery body:      y = 45..57
lightning:         y = 58..62
```

Ширина Wi-Fi і батареї — 9 пікселів. Між стовпчиком і часом залишається один
вільний піксель `x=10`.

## Перший тест і калібрування

У верхній частині скетча є чотири константи:

```cpp
static constexpr float BATTERY_VOLTAGE_SCALE = 1.000f;
static constexpr float BATTERY_VOLTAGE_OFFSET = 0.000f;
static constexpr float BATTERY_EMPTY_VOLTAGE = 3.30f;
static constexpr float BATTERY_FULL_VOLTAGE = 4.20f;
```

Перший прохід:

1. Виміряти BAT+ мультиметром.
2. Відкрити Serial Monitor `115200`.
3. Порівняти мультиметр з рядком:
   `Battery ADC: ... mV / BAT: ... V / ...%`.
4. Після реальних значень підкрутити `SCALE/OFFSET`.
5. Окремо узгодити реальні `EMPTY/FULL` для батареї HU-009.

## Бібліотеки

- U8g2
- ArduinoJson
- ESP32 Arduino core (`WiFi`, `HTTPClient`, `WebServer`, `DNSServer`,
  `Preferences`)
